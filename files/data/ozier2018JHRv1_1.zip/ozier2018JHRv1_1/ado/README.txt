This directory contains only the DCdensity.ado file, written by Brian Kovac and Justin McCrary.

Move/copy it to your C:\ado\personal directory or wherever such files are stored on your system (type sysdir at the Stata prompt to see a listing).

This is needed for the lower panels of Figure 1.
