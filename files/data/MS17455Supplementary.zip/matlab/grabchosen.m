% Written by PJ and OWO March 2012


function Z=grabchosen(chosen,np,v,ndraws);

    Z=reshape(chosen,1,np,1); % Grab chosen investment amounts
    Z=repmat(Z,[1,1,ndraws]);
    for n=1:np; % Replace the chosen investment with its EU
        j=Z(1,n,1);
        j=j/10;
        j=j+1;
        Z(1,n,:)=v(j,n,:);
        
    end;
