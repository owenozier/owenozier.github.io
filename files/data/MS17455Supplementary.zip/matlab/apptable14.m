% Estimate mixed logit using Jakiela-Ozier (2015) data

clear all

global T 
global B W Q T K D 
global NDRAWS SEED1 LLTOL
global cp ct cp1 cp2 cp3 cp4 cp5 cp6 
global NP NP1 NP2 NP3 NP4 NP5 NP6 
global cb1 cb2 cb3 cb4 cb5 cb6 
global cep3 cep6 ch3 ch6 ce3 ce6 
global DR1 DR2 DR3 DR4 DR5 DR6 
global rho1 rho2 rho3 rho4 rho5 rho6 
global d1 d2 d3 d4 d5 d6 
global KR2 KR3 KR5 KR6 
global XSMALL XLARGE
global X1 X2 X3N X3A X3H X4 X5 X6A X6N X6H
global P3 P6 NEG3 NEG6
global H4 H5 H6 H6B H100
global EXITDATA ESTKAPPA LINTAU
global TMAT2 TMAT3 TMAT5 TMAT6 tsize psize
global reallysmall reallybig
global estIndicators estBetahat estSEhat estNames
global pw1 pw2 pw3 sw1 sw2 sw3 fw1 fw2 fw3 pm1 pm2 pm3 sm1 sm2 sm3 fm1 fm2 fm3
global thisflag thisparam thisstderr thisminutes


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% LOAD DATA 

XMAT=load('rivewomenALL.csv'); 
%XMAT=load('rivemenALL.csv'); 

NDRAWS=500; 
SEED1 = 1234; 
randn('state',SEED1) 
rand('state',SEED1)  
cp=XMAT(:,1); 
NP=cp(end,1); 
ct=XMAT(:,2); 

for i=1:6  
    eval(['cp' num2str(i) '=XMAT(ct==i,1);']) 
    eval(['NP' num2str(i) '=size(cp' num2str(i) ',1);'])
    eval(['cb' num2str(i) '=XMAT(ct==i,3);']) 
    eval(['cep' num2str(i) '=XMAT(ct==i,4);']) 
    eval(['ch' num2str(i) '=XMAT(ct==i,5);']) 
    eval(['ce' num2str(i) '=XMAT(ct==i,6);']) 
    eval(['TMP' num2str(i) '=2*rand(1,NP'  num2str(i) ',NDRAWS)-1; ']) 
    eval(['DR' num2str(i) '=sqrt(6)*(1-sqrt(abs(TMP'  num2str(i) '))).*(1-2*(TMP' num2str(i) '<0)); ']) 
end

reallysmall=1/1000000;
reallybig=1000000;

XSMALL=linspace(0,80,9); 
XSMALL=[XSMALL' XSMALL']; 
XSMALL(:,1)=80.-XSMALL(:,1); 
XSMALL(9,1)=reallysmall; 
XSMALL(:,2)=80.+4.*XSMALL(:,2); 
XSMALL=reshape(XSMALL,9,2,1,1); 

XLARGE=linspace(0,180,19);
XLARGE=[XLARGE' XLARGE'];
XLARGE(:,1)=180.-XLARGE(:,1);
XLARGE(19,1)=reallysmall;
XLARGE(:,2)=180.+4.*XLARGE(:,2);
XLARGE=reshape(XLARGE,19,2,1,1); 

H100=zeros(19,2); 
H100(1:9,:)=100; 
H100=reshape(H100,19,2,1,1);

X1=repmat(XSMALL,[1,1,NP1,NDRAWS]);
X4=repmat(XLARGE,[1,1,NP4,NDRAWS]); 
X2=repmat(XSMALL,[1,1,NP2,NDRAWS]); 
X5=repmat(XLARGE,[1,1,NP5,NDRAWS]); 
H5=repmat(H100,[1,1,NP5,NDRAWS]);
X3N=repmat(XSMALL,[1,1,NP3,NDRAWS]); 

X3A=repmat(XSMALL,[1,1,NP3,NDRAWS]); 
ep=reshape(cep3,1,1,NP3,1); 
ep=repmat(ep,[9,2,1,NDRAWS]);
X3A=X3A-ep;
X3A(X3A==0)=reallysmall; 
NEG3=X3A<0; 
NEG3=reallybig.*NEG3; 
X3A(X3A<0)=reallysmall; 

P3=80-cb3+(5.*ch3).*cb3; 
P3=reshape(P3,1,NP3,1);
P3=repmat(P3,[2,1,NDRAWS]);
ep=reshape(cep3,1,NP3,1); 
ep=repmat(ep,[2,1,NDRAWS]);
ep(2,:,:)=0; 
P3=P3-ep; 
P3(P3==0)=reallysmall;

X6N=repmat(XLARGE,[1,1,NP6,NDRAWS]); 
H6=repmat(H100,[1,1,NP6,NDRAWS]);

X6A=repmat(XLARGE,[1,1,NP6,NDRAWS]); 
ep=reshape(cep6,1,1,NP6,1);
ep=repmat(ep,[19,2,1,NDRAWS]);
X6A=X6A-ep;
X6A(X6A==0)=reallysmall; 
NEG6=X6A<0; 
NEG6=reallybig.*NEG6;
X6A(X6A<0)=reallysmall; 

P6=180-cb6+(5.*ch6).*cb6; 
P6=reshape(P6,1,NP6,1);
P6=repmat(P6,[2,1,NDRAWS]);
ep=reshape(cep6,1,NP6,1); 
ep=repmat(ep,[2,1,NDRAWS]);
ep(2,:,:)=0; 
P6=P6-ep; 
P6(P6==0)=reallysmall; 
H6B=cb6<90;
H6B=100.*H6B;
H6B=reshape(H6B,1,NP6);
H6B=repmat(H6B,[2,1]);
H6B(1,:)=0;
H6B=reshape(H6B,2,NP6,1);
H6B=repmat(H6B,[1,1,NDRAWS]);
    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% ESTIMATION 

T=[ 1 ; 2 ; 3 ; 4 ; 5 ; 6 ];
B=[ 0.6 ]; 
W=[ 0.1 ]; 
Q=[ 0.04 ]; 
Z=[ 0.05 ]; 
G=[ 0.5 ]; 
K=[ 0.25 ]; 

EXITDATA = 0; 
LINTAU = 0; 
ESTKAPPA = 0; 
param=[B;W;Q]; 
if sum(T==5)==1;
    param(end+1,1)=Z;
end;
if EXITDATA==1; 
    param(end+1,1)=G;
    if ESTKAPPA==1; 
        param(end+1,1)=K;       
    end;
end;

if LINTAU==1;
    psize=size(param,1);
    tsize=size(TMAT5,2);
    tstart=0.01.*ones(tsize,1);
    param=[param ; tstart];
end;

MAXITERS=[]; 
PARAMTOL=[];
LLTOL=0.005;

options=optimset('LargeScale','off','Display','iter','GradObj','off',...
    'MaxFunEvals',10000,'MaxIter',MAXITERS,'TolX',PARAMTOL,'TolFun',LLTOL,'DerivativeCheck','off');
[paramhat,fval,exitflag,output,grad,hessian]=fminunc(@lltable7,param,options); %not 2015 ll here, since appendix table.

disp(' ');
if exitflag == 1
  disp('Convergence achieved.');
elseif exitflag == 2
  disp('Convergence achieved by criterion based on change in parameters.');
elseif exitflag == 3
  disp('Convergence achieved by criterion based on change in log-likelihood value.');
else
    disp('Convergence not achieved.');
    %return %commented out in 2015 c2 for runner.
end

ihess=inv(hessian);
stderr=sqrt(diag(ihess));
paramhat(2,1)=abs(paramhat(2,1));
