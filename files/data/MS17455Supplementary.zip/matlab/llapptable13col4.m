
function [ll]=llapptable13col4(param)

global T 
global B W Q T K D
global XMAT NDRAWS SEED1 
global cp ct cp1 cp2 cp3 cp4 cp5 cp6 
global NP NP1 NP2 NP3 NP4 NP5 NP6 
global cb1 cb2 cb3 cb4 cb5 cb6 
global cep3 cep6 ch3 ch6 ce3 ce6 
global DR1 DR2 DR3 DR4 DR5 DR6 
global rho1 rho2 rho3 rho4 rho5 rho6 
global d1 d2 d3 d4 d5 d6 
global KR2 KR3 KR5 KR6 
global XSMALL XLARGE
global X1 X2 X3N X3A X3H X4 X5 X6A X6N X6H
global v1 v2 v3 v3A v3N v3H v4 v5 v6 v6A v6N v6H
global P3 P6 NEG3 NEG6
global H4 H5 H6 H6B H100
global reallysmall reallybig

COUNT=NP1+NP4;
b=param(1,1);
w=param(2,1);
sigma=param(3,1);

p=zeros(1,COUNT);

for i=1:6 
    eval(['rho' num2str(i) '=repmat(b,[1,NP'  num2str(i) ',NDRAWS])+repmat(w,[1,NP'  num2str(i) ',NDRAWS]).*DR' num2str(i) ';'])
    eval(['rho' num2str(i) '=ones(1,NP'  num2str(i) ',NDRAWS)-rho' num2str(i) ';'])
end

for i=1:3;
    eval(['u80_' num2str(i) '=400.*ones(1,NP' num2str(i) ',NDRAWS);'])
    eval(['u80_' num2str(i) '=u80_' num2str(i) '.^rho' num2str(i) ';'])
    eval(['u10_' num2str(i) '=10.*ones(1,NP' num2str(i) ',NDRAWS);'])
    eval(['u10_' num2str(i) '=u10_' num2str(i) '.^rho' num2str(i) ';'])
    eval(['d' num2str(i) '=u80_' num2str(i) '-u10_' num2str(i) ';'])
    eval(['d' num2str(i) '=reshape(d' num2str(i) ',1,1,NP' num2str(i) ',NDRAWS);'])
    eval(['clear u80_' num2str(i) 'u10_' num2str(i) ';'])
end;

for i=4:6;
    eval(['u80_' num2str(i) '=900.*ones(1,NP' num2str(i) ',NDRAWS);'])
    eval(['u80_' num2str(i) '=u80_' num2str(i) '.^rho' num2str(i) ';'])
    eval(['u10_' num2str(i) '=10.*ones(1,NP' num2str(i) ',NDRAWS);'])
    eval(['u10_' num2str(i) '=u10_' num2str(i) '.^rho' num2str(i) ';'])
    eval(['d' num2str(i) '=u80_' num2str(i) '-u10_' num2str(i) ';'])
    eval(['d' num2str(i) '=reshape(d' num2str(i) ',1,1,NP' num2str(i) ',NDRAWS);'])
    eval(['clear u80_' num2str(i) 'u10_' num2str(i) ';'])
end;

for i=1:6 
    eval(['rho' num2str(i) '=reshape(rho' num2str(i) ',1,1,NP' num2str(i) ',NDRAWS);'])
end

if sum(T==1)==1;
    
    rho1=repmat(rho1,[9,2,1,1]);
    d1=repmat(d1,[9,2,1,1]);
    v1=(X1.^rho1)./(2.*d1); 
    v1=reshape(sum(v1,2),9,NP1,NDRAWS); 
    C1=grabchosen(cb1,NP1,v1,NDRAWS);
    pp1=gologit(v1,C1,sigma,NP1,NDRAWS);
    
end;

if sum(T==4)==1;

    rho4=repmat(rho4,[19,2,1,1]);
    d4=repmat(d4,[19,2,1,1]);
    v4=(X4.^rho4)./(2.*d4); 
    v4=reshape(sum(v4,2),19,NP4,NDRAWS); 
    C4=grabchosen(cb4,NP4,v4,NDRAWS);   
    pp4=gologit(v4,C4,sigma,NP4,NDRAWS);
    
end;

pp=[ pp1 ; pp4 ];

pp=sum(pp,2); 
pp=pp';
p=p+pp;
p=p./NDRAWS;
p(1,isnan(p))=1;

ll=-sum(log(p),2);


