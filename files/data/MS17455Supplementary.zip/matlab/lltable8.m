
% Written by PJ & OWO

function [ll]=lltable8(param)

global T 
global B W Q T K D 
global XMAT NDRAWS SEED1 
global cp ct cp1 cp2 cp3 cp4 cp5 cp6 
global NP NP1 NP2 NP3 NP4 NP5 NP6 
global cb1 cb2 cb3 cb4 cb5 cb6 
global cep3 cep6 ch3 ch6 ce3 ce6 
global DR1 DR2 DR3 DR4 DR5 DR6 
global rho1 rho2 rho3 rho4 rho5 rho6 
global d1 d2 d3 d4 d5 d6 
global KR2 KR3 KR5 KR6 
global XSMALL XLARGE
global X1 X2 X3N X3A X3H X4 X5 X6A X6N X6H
global v1 v2 v3 v3A v3N v3H v4 v5 v6 v6A v6N v6H
global P3 P6 NEG3 NEG6
global H4 H5 H6 H6B H100
global EXITDATA ESTKAPPA LINTAU
global TMAT2 TMAT3 TMAT5 TMAT6 tsize psize
global reallysmall reallybig

COUNT=NP1+NP4;
b=param(1,1);
w=param(2,1);
sigma=param(3,1);
    
if sum(T==5)==1; 
    tau=param(4,1);
    COUNT=COUNT+NP5;
end;

if sum(T==2)==1;
    COUNT=COUNT+NP2;
end;

if sum(T==3)==1;
    COUNT=COUNT+NP3;
end;

if sum(T==6)==1;
    COUNT=COUNT+NP6;
end;

if EXITDATA==1; 
    gamma=param(5,1);
    if ESTKAPPA==1; 
        kappa=param(6,1);      
    end;
end;

if LINTAU==1;
    a=psize+1;
    z=psize+tsize;
    tauvec=param(a:z,1);
end;

p=zeros(1,COUNT);

for i=1:6 
    eval(['rho' num2str(i) '=repmat(b,[1,NP'  num2str(i) ',NDRAWS])+repmat(w,[1,NP'  num2str(i) ',NDRAWS]).*DR' num2str(i) ';'])
    eval(['rho' num2str(i) '=max(0,rho' num2str(i) ');']) % only line added 2012.07.30
    eval(['rho' num2str(i) '=ones(1,NP'  num2str(i) ',NDRAWS)-rho' num2str(i) ';'])
end

for i=1:6; 
    eval(['u900_' num2str(i) '=900.*ones(1,NP' num2str(i) ',NDRAWS);'])
    eval(['u900_' num2str(i) '=u900_' num2str(i) '.^rho' num2str(i) ';'])
    eval(['u10_' num2str(i) '=10.*ones(1,NP' num2str(i) ',NDRAWS);'])
    eval(['u10_' num2str(i) '=u10_' num2str(i) '.^rho' num2str(i) ';'])
    eval(['d' num2str(i) '=u900_' num2str(i) '-u10_' num2str(i) ';'])
    eval(['d' num2str(i) '=reshape(d' num2str(i) ',1,1,NP' num2str(i) ',NDRAWS);'])
    eval(['clear u900_' num2str(i) 'u10_' num2str(i) ';'])
end;

for i=1:6 
    eval(['rho' num2str(i) '=reshape(rho' num2str(i) ',1,1,NP' num2str(i) ',NDRAWS);'])
end

% TREATMENT 1:  PRIVATE x SMALL ENDOWMENT

rho1=repmat(rho1,[9,2,1,1]);
d1=repmat(d1,[9,2,1,1]);
v1=(X1.^rho1)./(2.*d1); 
v1=reshape(sum(v1,2),9,NP1,NDRAWS); 
C1=grabchosen(cb1,NP1,v1,NDRAWS);
pp1=gologit(v1,C1,sigma,NP1,NDRAWS);

% TREATMENT 4:  PRIVATE x LARGE ENDOWMENT

rho4=repmat(rho4,[19,2,1,1]);
d4=repmat(d4,[19,2,1,1]);
v4=(X4.^rho4)./(2.*d4); 
v4=reshape(sum(v4,2),19,NP4,NDRAWS); 
C4=grabchosen(cb4,NP4,v4,NDRAWS);   
pp4=gologit(v4,C4,sigma,NP4,NDRAWS);

% TREATMENT 2:  PUBLIC x SMALL ENDOWMENT

if sum(T==2)==1;

    rho2=repmat(rho2,[9,2,1,1]);
    d2=repmat(d2,[9,2,1,1]);
    if LINTAU==0;
        t=ones(9,2,NP2,NDRAWS);
        t=(1-tau).*t;
    elseif LINTAU==1;
        t=tau.*(ones(NP2,1)-TMAT2); 
        vartau=TMAT2*tauvec;
        t=t+vartau;        
        t=ones(NP2,1)-t;
        t=reshape(t,1,1,NP2,1);
        t=repmat(t,[9,2,1,NDRAWS]);
    end;
    v2=t.*X2;
    v2=(v2.^rho2)./(2.*d2);
    v2=reshape(sum(v2,2),9,NP2,NDRAWS); 

    if ESTKAPPA==1;
         k=kappa.*ones(9,NP2,NDRAWS); 
         v2=v2-k;
    end;

    C2=grabchosen(cb2,NP2,v2,NDRAWS); 
    pp2=gologit(v2,C2,sigma,NP2,NDRAWS);
    
end;

% TREATMENT 5:  PUBLIC x LARGE ENDOWMENT

if sum(T==5)==1;

    rho5=repmat(rho5,[19,2,1,1]);
    d5=repmat(d5,[19,2,1,1]);
    if LINTAU==0;
        t=ones(19,2,NP5,NDRAWS);
        t=(1-tau).*t;
    elseif LINTAU==1;
        t=tau.*(ones(NP5,1)-TMAT5); 
        vartau=TMAT5*tauvec;
        t=t+vartau;
        t=ones(NP5,1)-t;
        t=reshape(t,1,1,NP5,1);
        t=repmat(t,[19,2,1,NDRAWS]);
    end;
    v5=X5-H5; 
    v5=t.*v5; 
    v5=v5+H5; 
    v5=(v5.^rho5)./(2.*d5); 
    v5=reshape(sum(v5,2),19,NP5,NDRAWS); 

    if ESTKAPPA==1;
         k=kappa.*ones(19,NP5,NDRAWS); 
         v5=v5-k;
    end;

    C5=grabchosen(cb5,NP5,v5,NDRAWS); 
    pp5=gologit(v5,C5,sigma,NP5,NDRAWS);
    
end;

% TREATMENT 3:  PRICE x SMALL ENDOWMENT

if sum(T==3)==1;

    r=repmat(rho3,[9,2,1,1]);
    denom=repmat(d3,[9,2,1,1]);
    if LINTAU==0;
        t=ones(9,2,NP3,NDRAWS);
        t=(1-tau).*t;
    elseif LINTAU==1;
        t=tau.*(ones(NP3,1)-TMAT3); 
        vartau=TMAT3*tauvec;
        t=t+vartau;
        t=ones(NP3,1)-t;
        t=reshape(t,1,1,NP3,1);
        t=repmat(t,[9,2,1,NDRAWS]);
    end;
    v3N=t.*X3N; 
    v3N=(v3N.^r)./(2.*denom); 

    if ESTKAPPA==1;
        k=(kappa/2).*ones(9,2,NP3,NDRAWS);
        v3N=v3N-k; 
    end;

    v3A=(X3A.^r)./(2.*denom);
    v3A=v3A-NEG3; 
    v3H=v3A; 
    v3H(:,1,:,:)=v3N(:,1,:,:);
    v3N=sum(v3N,2); 
    v3A=sum(v3A,2);
    v3H=sum(v3H,2); 
    v3=cat(2,v3N,v3H,v3A); 
    v3=reshape(max(v3,[],2),9,NP3,NDRAWS); 

    C3=grabchosen(cb3,NP3,v3,NDRAWS); 
    pp3=gologit(v3,C3,sigma,NP3,NDRAWS);
    
    if EXITDATA==1;

        r=reshape(rho3,1,NP3,NDRAWS); 
        r=repmat(r,[2,1,1]); 
        denom=reshape(d3,1,NP3,NDRAWS); 
        denom=repmat(denom,[2,1,1]); 
        if LINTAU==0;
            t=ones(2,NP3,NDRAWS);
            t=(1-tau).*t;
        elseif LINTAU==1;
            t=tau.*(ones(NP3,1)-TMAT3); 
            vartau=TMAT3*tauvec;
            t=t+vartau;
            t=ones(NP3,1)-t;
            t=reshape(t,1,NP3,1);
            t=repmat(t,[2,1,NDRAWS]);
        end;
        t(1,:,:)=1; 
        NEG=P3<0; 
        NEG=reallybig.*NEG; 
        v3B=P3;
        v3B(v3B<0)=reallysmall;
        v3B=t.*v3B; 
        v3B=(v3B.^r)./denom; 
        v3B=v3B-NEG; 
        if ESTKAPPA==1;
            k=kappa.*ones(2,NP3,NDRAWS); 
            k(1,:,:)=0; 
            v3B=v3B-k;
        end;
        v3B=v3B(2,:,:)-v3B(1,:,:); 
        v3B=reshape(v3B,NP3,NDRAWS);
        e=ce3; 
        e(e==0)=-1;
        e=repmat(e,[1,NDRAWS]);
        v3B=e.*v3B;
        v3B=v3B./gamma; 
        v3B=exp(v3B);
        v3B(isinf(v3B))=10.^20;
        v3B=1./(1+v3B);
        v3B=reshape(v3B,1,NP3,NDRAWS);
        pp3=reshape(pp3,1,NP3,NDRAWS);
        pp3=cat(1,pp3,v3B);
        pp3=prod(pp3,1);
        pp3=reshape(pp3,NP3,NDRAWS);

    end;    
    
end;

% TREATMENT 6:  PRICE x LARGE ENDOWMENT

if sum(T==6)==1;

    r=repmat(rho6,[19,2,1,1]);
    denom=repmat(d6,[19,2,1,1]);
    if LINTAU==0;
        t=ones(19,2,NP6,NDRAWS);
        t=(1-tau).*t;
    elseif LINTAU==1;
        t=tau.*(ones(NP6,1)-TMAT6); 
        vartau=TMAT6*tauvec;
        t=t+vartau;
        t=ones(NP6,1)-t;
        t=reshape(t,1,1,NP6,1);
        t=repmat(t,[19,2,1,NDRAWS]);
    end;
    v6N=X6N-H6; 
    v6N=t.*v6N; 
    v6N=v6N+H6; 
    v6N=(v6N.^r)./(2.*denom); 
     if ESTKAPPA==1;
        k=(kappa/2).*ones(19,2,NP6,NDRAWS);
        v6N=v6N-k;     
     end;

    v6A=X6A.^r;
    v6A=v6A./(2.*denom);
    v6A=v6A-NEG6; 

    v6H=v6A; 
    v6H(:,1,:,:)=v6N(:,1,:,:);

    v6N=sum(v6N,2); 
    v6A=sum(v6A,2);
    v6H=sum(v6H,2); 
    v6=cat(2,v6N,v6H,v6A); 
    v6=reshape(max(v6,[],2),19,NP6,NDRAWS); 

    C6=grabchosen(cb6,NP6,v6,NDRAWS);
    pp6=gologit(v6,C6,sigma,NP6,NDRAWS);

    if EXITDATA==1;
        
        r=reshape(rho6,1,NP6,NDRAWS); 
        r=repmat(r,[2,1,1]); 
        denom=reshape(d6,1,NP6,NDRAWS);
        denom=repmat(denom,[2,1,1]); 
        if LINTAU==0;
            t=ones(2,NP6,NDRAWS);
            t=(1-tau).*t;
        elseif LINTAU==1;
            %t=tau.*ones(NP6,1);
            t=tau.*(ones(NP6,1)-TMAT6); 
            vartau=TMAT6*tauvec;
            t=t+vartau;
            t=ones(NP6,1)-t;
            t=reshape(t,1,NP6,1);
            t=repmat(t,[2,1,NDRAWS]);
        end;
        t(1,:,:)=1; 
        NEG=P6<0; 
        NEG=reallybig.*NEG;
        v6B=P6;
        v6B(v6B<0)=reallysmall; 
        v6B=v6B-H6B; 
        v6B=t.*v6B;
        v6B=v6B+H6B; 
        v6B=(v6B.^r)./denom; 
        v6B=v6B-NEG; 
        if ESTKAPPA==1;
            k=kappa.*ones(2,NP6,NDRAWS);      
            k(1,:,:)=0; 
        	v6B=v6B-k;
        end;
        v6B=v6B(2,:,:)-v6B(1,:,:); 
        v6B=reshape(v6B,NP6,NDRAWS);
        e=ce6; 
        e(e==0)=-1; 
        e=repmat(e,[1,NDRAWS]);
        v6B=e.*v6B;
        v6B=v6B./gamma; 
        v6B=exp(v6B);
        v6B(isinf(v6B))=10.^20;
        v6B=1./(1+v6B);
        v6B=reshape(v6B,1,NP6,NDRAWS);
        pp6=reshape(pp6,[1,NP6,NDRAWS]);
        pp6=cat(1,pp6,v6B);
        pp6=prod(pp6,1);
        pp6=reshape(pp6,[NP6,NDRAWS]);
        
    end;
    
end;

pp=[ pp1 ; pp4 ];

if sum(T==2)==1;
    pp=[ pp ; pp2 ];
end;

if sum(T==5)==1;
    pp=[ pp ; pp5 ];
end;

if sum(T==3)==1 & sum(T==6)==1;
    pp=[ pp ; pp3 ; pp6 ];
end;

pp=sum(pp,2); 
pp=pp';
p=p+pp;
p=p./NDRAWS;
p(1,isnan(p))=1;

ll=-sum(log(p),2);


