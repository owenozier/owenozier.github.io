% Written by PJ and OWO March 2012
% Creates a vector of probabilities of observed investment choices

function Z=gologit(v,chosenEUs,noisehat,np,ndraws);

nineornineteen=size(v,1);
vv=v-repmat(chosenEUs,[nineornineteen,1,1]);
vv=vv./noisehat;
vv=exp(vv);
vv(isinf(vv))=10.^20;  % As precaution when exp(vv) is too large
Z=1./(sum(vv,1)); % Z is 1 x np x ndraws
Z=reshape(Z,[np,ndraws]);
