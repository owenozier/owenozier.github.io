The do files jakiela-ozier-replication-files and jakiela-ozier-replication-files-appendix
should be saved in the same directory with jakiela-ozier-data.dta.  The do files generate all
Stata results and figures reported in the paper and the appendix.
